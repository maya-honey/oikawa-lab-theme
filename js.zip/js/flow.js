window.addEventListener('DOMContentLoaded', function(){
  count = 0;
  $(".flow-next-button").off('click');
  $(".flow-next-button ").click(function(){

    $button = $(".flow-next-button");
    $ul = $(".flow-c-f-c-ul");
    $num1 = $(".ultra_number_1");
    $num2 = $(".ultra_number_2");
    $num3 = $(".ultra_number_3");
    $num4 = $(".ultra_number_4");
    $num5 = $(".ultra_number_5");
    $coltex1 = $(".flow-color_1");
    $coltex2 = $(".flow-color_2");
    $coltex3 = $(".flow-color_3");
    $coltex4 = $(".flow-color_4");
    $coltex5 = $(".flow-color_5");

    if($button.hasClass("flow-phase_0")){
      $ul.removeClass("slide-left_5");
      $ul.addClass("slide-left_1");

      $button.removeClass("flow-phase_0");
      $button.addClass("flow-phase_1");

      $num1.removeClass("opacity_1");
      $num2.addClass("opacity_1");

      $coltex1.removeClass("color_change_ultra");
      $coltex2.addClass("color_change_ultra");

    }else if ($button.hasClass("flow-phase_1")) {
      $ul.removeClass("slide-left_1");
      $ul.addClass("slide-left_2");

      $button.removeClass("flow-phase_1");
      $button.addClass("flow-phase_2");

      $num2.removeClass("opacity_1");
      $num3.addClass("opacity_1");

      $coltex2.removeClass("color_change_ultra");
      $coltex3.addClass("color_change_ultra");

    }else if ($button.hasClass("flow-phase_2")) {
      $ul.removeClass("slide-left_2");
      $ul.addClass("slide-left_3");

      $button.removeClass("flow-phase_2");
      $button.addClass("flow-phase_3");

      $num3.removeClass("opacity_1");
      $num4.addClass("opacity_1");

      $coltex3.removeClass("color_change_ultra");
      $coltex4.addClass("color_change_ultra");

    }else if ($button.hasClass("flow-phase_3")) {
      $ul.removeClass("slide-left_3");
      $ul.addClass("slide-left_4");

      $button.removeClass("flow-phase_3");
      $button.addClass("flow-phase_4");

      $num4.removeClass("opacity_1");
      $num5.addClass("opacity_1");

      $coltex4.removeClass("color_change_ultra");
      $coltex5.addClass("color_change_ultra");

    }else if ($button.hasClass("flow-phase_4")) {
      $ul.removeClass("slide-left_4");
      $ul.addClass("slide-left_5");

      $button.removeClass("flow-phase_4");
      $button.addClass("flow-phase_0");

      $num5.removeClass("opacity_1");
      $num1.addClass("opacity_1");

      $coltex5.removeClass("color_change_ultra");
      $coltex1.addClass("color_change_ultra");

    }






  });

});
