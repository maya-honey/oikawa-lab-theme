jQuery(function() {
  jQuery("#navbutton").click(function() {
      jQuery("#header-nav-wrap-sp").slideToggle();
      if($(".header-nav").hasClass("atraction")){
        $(".header-nav").removeClass("atraction");
      }else{
        $(".header-nav").addClass("atraction");
      }
  });
});
