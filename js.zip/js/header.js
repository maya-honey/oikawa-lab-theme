$(function(){

  //headerのフェード設定
  $(window).scroll(function(){
    $('header').each(function(){
      var nowposition = $(this).offset().top;
      var scroll = $(window).scrollTop();
      var windowheight = $(window).height();

      var countnum = 0;

      if(scroll>=10){
        $(".h-c-us-m-u-c-frame").addClass("header-change-color");
        $("header").addClass("header-shadow");

      }else{
        $(".h-c-us-m-u-c-frame").removeClass("header-change-color");
        $("header").removeClass("header-shadow");
      }
    });
  });


});
