<aside id="sidebar" class="sidebar">
  <div class="side-content">
    <section>
      <div class="side-c-profile">
        <div class="ribbon13">
          <h1>このラボの中の人</h1>
        </div>
        <div class="side-c-p-img">

        </div>
        <h2>及川和明</h2>
        <p>2000年1月1日岩手県盛岡市生まれ。立命館大学○○学部卒業後、大手学習塾講師としてスカウトされ、「教育・子育て」現場の最前線にて見識を深める。2003年より同学習塾塾長兼経営者に就任。</p>
        <p>脳科学・心理学に加え、300人以上の指導経験を根拠とした指導・アドバイスが特徴。</p>
      </div>
    </section>
    <section>
      <div class="side-c-recommend">
        
      </div>
    </section>
  </div>
</aside>
