<?php get_header(); ?>

<section class="fv">
  <div class="fv-content">
    <div class="fv-c-image_frame">

    </div>
    <div class="fv-c-message_frame">
      <div class="fv-c-mf-frame">
        <h1>デジタルマーケティングで<br />さらなる事業成長を。</h1>
        <p>何から始めて、どう動き、いかに改善すればいいのか。<br />正解が分からず、不安なゼロ地点。</p>
        <br />
        <p>そんな「初めの一歩」から、あなたと共に歩みます。</p>
        <br>
        <p>マーケティングのデジタル化支援なら、お任せください。</p>
        <div class="matomerukunn">
          <a href="https://oikawa-lab.net/contact/">
            <div class="fv-c-mf-mail">
              <div class="fv-c-mf-m-white">
                <p>メールで問い合わせる</p>
              </div>
            </div>
          </a>
          <a href="#">
            <div class="fv-c-mf-chat">
              <div class="fv-c-mf-c-white">
                <p>チャットで相談する</p>
              </div>
            </div>
          </a>
        </div>
      </div>
    </div>
  </div>
</section>
<section class="philosopy">
  <div class="p-content">
    <div class="p-c-message_frame">
      <div class="p-c-mf-frame">
        <h1>デジタルマーケティングの<br />"初めて"をサポート</h1>
        <p>及川ラボでは、マーケティングのデジタル化支援に<br />特化したサービスを提供しています。</p>
        <br />
        <p>パソコンやネットが苦手でも、<br />社内にノウハウが無くても、大丈夫。</p>
        <br />
        <p>及川ラボが御社の新たなWeb担当として、全力でご支援いたします。</p>
      </div>
    </div>
    <div class="p-c-image_frame">
      <img src="image/top/top_philosopy.png" alt="">
    </div>
  </div>
</section>
<section class="issue">
  <div class="i-content">
    <div class="i-c-background">

    </div>
    <div class="i-c-text">
      <h1>こんなお悩みを解決します</h1>
      <p>マーケティングのデジタル化支援における、あらゆる課題を解決いたします。<br />そのお悩み、まずは及川ラボにご相談ください。</p>
    </div>
    <ul class="i-c-point">
      <li class="i-c-p-1">
        <div class="i-c-p-common_frame">
          <div class="i-c-p-cf-content">
            <h2>ホームページを作って、Web集客の基盤にしたい</h2>
            <img src="image/top/top_issue_1.png" alt="">
            <p>ホームページの制作からその後の運用まで、まとめて支援してもらいたい</p>
          </div>
        </div>
      </li>
      <li class="i-c-p-2">
        <div class="i-c-p-common_frame">
          <div class="i-c-p-cf-content">
            <h2>色々な施策を売っているが売り上げにつながらない</h2>
            <img src="image/top/top_issue_2.png" alt="">
            <p>すでにデジタルマーケティングを始めているが、一向に効果が上がらない</p>
          </div>
        </div>
      </li>
      <li class="i-c-p-3">
        <div class="i-c-p-common_frame">
          <div class="i-c-p-cf-content">
            <h2>集客にSNSをしたいが、社内にノウハウが無い</h2>
            <img src="image/top/top_issue_3.png" alt="">
            <p>Instagram、Twitter、Line。何をどう活用すればいいのか、正解が分からない</p>
          </div>
        </div>
      </li>
      <li class="i-c-p-4">
        <div class="i-c-p-common_frame">
          <div class="i-c-p-cf-content">
            <h2>何から手を付けていいか分からない</h2>
            <img src="image/top/top_issue_4.png" alt="">
            <p>ネットで集客してみたいが、何からどう始めれば良いのか分からない</p>
          </div>
        </div>
      </li>
    </ul>
    <div class="i-c-scroll">

    </div>
  </div>
  <div class="i-go_rinen">
    <a href="https://oikawa-lab.net/philosophy/">
      <div class="i-gr-white">
        <p>私たちの理念</p>
      </div>
    </a>
  </div>

</section>
<section class="service">
  <div class="s-content">
    <h1>Our Service</h1>
    <div class="s-c-srvice">
      <ul class="s-c-s-ul s-c-s-u-1">
        <li>
          <div class="s-c-s-u-l-image">
            <img src="image/top/top_service_1.png" alt="">
          </div>
        </li>
        <li>
          <div class="s-c-s-u-l-text">
            <h2>1. Web Design</h2>
            <h3>ホームページ制作/開発</h3>
            <p>中小企業・個人向けの格安ホームページ制作サービスです。<br />制作も、運営も、更新も、管理も、<br />まるっとすべて及川ラボにお任せください。</p>
            <div class="service_readmore">
              <a href="https://oikawa-lab.net/service/webdesign/">
                <div class="sr-white">
                  <p>Read more</p>
                </div>
              </a>
            </div>
          </div>
        </li>
      </ul>
      <ul class="s-c-s-ul s-c-s-u-2">
        <li class="sp-open">
          <div class="s-c-s-u-l-image">
            <img src="image/top/top_service_2.png" alt="">
          </div>
        </li>
        <li>
          <div class="s-c-s-u-l-text">
            <h2>2. Web Management</h2>
            <h3>Web運用/マーケティング支援</h3>
            <p>SEOを駆使したWeb集客、徹底支援するサービスです。<br />個人ブログのアフィリエイト支援から<br />企業のオウンドメディア構築まで対応します。</p>
            <div class="service_readmore">
              <a href="https://oikawa-lab.net/service/webmanagement/">
                <div class="sr-white">
                  <p>Read more</p>
                </div>
              </a>
            </div>
          </div>
        </li>
        <li class="sp-close">
          <div class="s-c-s-u-l-image">
            <img src="image/top/top_service_2.png" alt="">
          </div>
        </li>
      </ul>
      <ul class="s-c-s-ul s-c-s-u-3">
        <li>
          <div class="s-c-s-u-l-image">
            <img src="image/top/top_service_3.png" alt="">
          </div>
        </li>
        <li>
          <div class="s-c-s-u-l-text">
            <h2>3. SNS Management</h2>
            <h3>LINE公式アカウント開設/運用支援</h3>
            <p>LINE公式アカウント開設・運用を、トータル支援するサービスです。<br />新規獲得、顧客育成、リピーター創出など<br />LINE集客のことなら、何でもお任せください。</p>
            <div class="service_readmore">
              <a href="https://oikawa-lab.net/service/snsmanagement/">
                <div class="sr-white">
                  <p>Read more</p>
                </div>
              </a>
            </div>
          </div>
        </li>
      </ul>
      <ul class="s-c-s-ul s-c-s-u-4">
        <li class="sp-open">
          <div class="s-c-s-u-l-image">
            <img src="image/top/top_service_4.png" alt="">
          </div>
        </li>
        <li>
          <div class="s-c-s-u-l-text">
            <h2>4. Video Direction</h2>
            <h3>映像ディレクション/企画/編集</h3>
            <p>中小企業・個人向けの、映像制作支援サービスです。<br />社内用、広報用、Youtube用など、映像用途はなんでもOK。<br />企画・撮影・編集のすべてを代行いたします。</p>
            <div class="service_readmore">
              <a href="https://oikawa-lab.net/service/videodirection/">
                <div class="sr-white">
                  <p>Read more</p>
                </div>
              </a>
            </div>
          </div>
        </li>
        <li class="sp-close">
          <div class="s-c-s-u-l-image">
            <img src="image/top/top_service_4.png" alt="">
          </div>
        </li>
      </ul>
    </div>
  </div>
</section>
<section class="case">
  <div class="c-content">
    <div class="c-background">
      <h1>Our Case</h1>
      <div class="c-c-list">
        <div class="c-c-l-frame">
          <ul class="c-c-l-f-ul">
            <li>
              <a href="#">
                <img src="image/top/top_case_1.png" alt="">
              </a>
            </li>
            <li>
              <a href="#">
                <img src="image/top/top_case_2.png" alt="">
              </a>
            </li>
            <li>
              <a href="#">
                <img src="image/top/top_case_3.png" alt="">
              </a>
            </li>
            <li>
              <a href="#">
                <img src="image/top/top_case_4.png" alt="">
              </a>
            </li>
            <li>
              <a href="#">
                <img src="image/top/top_case_5.png" alt="">
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>
<section class="menu">
  <div class="m-content">
    <ul class="m-c-ul">
      <li class="m-c-u-l_1">
        <a href="#">
          <div class="m-c-u-l-frame_common m-c-u-l1-frame">
            <p class="m-c-u-l-fc-title">
              Recruit
            </p>
            <p class="m-c-u-l-fc-sub">
              求める人物像
            </p>
          </div>
        </a>
      </li>
      <li class="m-c-u-l_2">
        <a href="#">
          <div class="m-c-u-l-frame_common m-c-u-l2-frame">
            <p class="m-c-u-l-fc-title">
              News
            </p>
            <p class="m-c-u-l-fc-sub">
              お知らせ
            </p>
          </div>
        </a>
      </li>
      <li class="m-c-u-l_3">
        <a href="https://oikawa-lab.net/company/">
          <div class="m-c-u-l-frame_common m-c-u-l3-frame">
            <p class="m-c-u-l-fc-title">
              Company
            </p>
            <p class="m-c-u-l-fc-sub">
              会社情報
            </p>
          </div>
        </a>
      </li>
    </ul>
  </div>
</section>


<?php get_footer(); ?>
