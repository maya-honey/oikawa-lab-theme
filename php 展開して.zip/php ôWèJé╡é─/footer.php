
<!--js読み込み（start）-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<?php header_scripts(); ?>
<?php flow_scripts(); ?>
<?php question_scripts(); ?>
 <!--js読み込み（end）-->

<section class="go">
  <div class="g-content">
    <div class="g-c-frame">
      <h2>Contact</h2>
      <p class="g-c-f-nihon">お問い合わせ</p>
      <p class="g-c-f-main">お問い合わせは下記フォームより受け付けております。<br />お問い合わせ内容確認後、1~3日ほどで担当者よりご連絡させていただきます。</p>
      <div class="g-c-f-more">
        <a href="https://oikawa-lab.net/contact/">
          <div class="g-c-f-m-white">
            <p>メールでのご相談はこちらから</p>
          </div>
        </a>
      </div>
      <p class="g-c-f-tel">090-9960-2917</p>
      <p class="g-c-f-text">平日 10:00-18:00｜代表直通<br />（セールス目的のお電話はご遠慮ください）</p>
    </div>
  </div>
</section>

<footer>
  <div class="footer-ante">
    <div class="footer-a-link">
      <ul class="footer-a-l-ul">
        <li class="footer-a-l-u-li">
          <a href="https://oikawa-lab.net/service/webdesign/"><h2>ホームページ制作</h2></a>
          <ul class="footer-a-l-u-l-ul">
            <li>
              <a href="https://oikawa-lab.net/service/webdesign/#service"><p>サービス内容</p></a>
            </li>
            <li>
              <a href="https://oikawa-lab.net/service/webdesign/#case"><p>制作実績</p></a>
            </li>
            <li>
              <a href="https://oikawa-lab.net/service/webdesign/#price"><p>価格</p></a>
            </li>
            <li>
              <a href="https://oikawa-lab.net/service/webdesign/#qanda"><p>よくある質問</p></a>
            </li>
            <li>
              <a href="https://oikawa-lab.net/service/webdesign/#flow"><p>ご依頼の流れ</p></a>
            </li>
          </ul>
        </li>
        <li class="footer-a-l-u-li">
          <a href="https://oikawa-lab.net/service/webmanagement/"><h2>SEO対策</h2></a>
          <ul class="footer-a-l-u-l-ul">
            <li>
              <a href="https://oikawa-lab.net/service/webmanagement/#service"><p>サービス内容</p></a>
            </li>
            <li>
              <a href="https://oikawa-lab.net/service/webmanagement/#case"><p>制作実績</p></a>
            </li>
            <li>
              <a href="https://oikawa-lab.net/service/webmanagement/#price"><p>価格</p></a>
            </li>
            <li>
              <a href="https://oikawa-lab.net/service/webmanagement/#qanda"><p>よくある質問</p></a>
            </li>
            <li>
              <a href="https://oikawa-lab.net/service/webmanagement/#flow"><p>ご依頼の流れ</p></a>
            </li>
          </ul>
        </li>
        <li class="footer-a-l-u-li">
          <a href="https://oikawa-lab.net/service/snsmanagement"><h2>LINE公式運用</h2></a>
          <ul class="footer-a-l-u-l-ul">
            <li>
              <a href="https://oikawa-lab.net/service/snsmanagement/#service"><p>サービス内容</p></a>
            </li>
            <li>
              <a href="https://oikawa-lab.net/service/snsmanagement/#case"><p>制作実績</p></a>
            </li>
            <li>
              <a href="https://oikawa-lab.net/service/snsmanagement/#price"><p>価格</p></a>
            </li>
            <li>
              <a href="https://oikawa-lab.net/service/snsmanagement/#qanda"><p>よくある質問</p></a>
            </li>
            <li>
              <a href="https://oikawa-lab.net/service/snsmanagement/#flow"><p>ご依頼の流れ</p></a>
            </li>
          </ul>
        </li>
        <li class="footer-a-l-u-li">
          <a href="https://oikawa-lab.net/service/videodirection"><h2>映像制作</h2></a>
          <ul class="footer-a-l-u-l-ul">
            <li>
              <a href="https://oikawa-lab.net/service/videodirection/#service"><p>サービス内容</p></a>
            </li>
            <li>
              <a href="https://oikawa-lab.net/service/videodirection/#case"><p>制作実績</p></a>
            </li>
            <li>
              <a href="https://oikawa-lab.net/service/videodirection/#price"><p>価格</p></a>
            </li>
            <li>
              <a href="https://oikawa-lab.net/service/videodirection/#qanda"><p>よくある質問</p></a>
            </li>
            <li>
              <a href="https://oikawa-lab.net/service/videodirection/#flow"><p>ご依頼の流れ</p></a>
            </li>
          </ul>
        </li>
        <li class="footer-a-l-u-li">
          <a href="https://oikawa-lab.net/service/company"><h2>企業情報</h2></a>
          <ul class="footer-a-l-u-l-ul">
            <li>
              <a href="https://oikawa-lab.net/philosophy/"><p>制作理念</p></a>
            </li>
            <li>
              <a href="https://oikawa-lab.net/service/"><p>サービス一覧</p></a>
            </li>
            <li>
              <a href="https://oikawa-lab.net/case/"><p>実績一覧</p></a>
            </li>
            <li>
              <a href="https://oikawa-lab.net/company/"><p>組織概要</p></a>
            </li>
            <li>
              <a href="https://oikawa-lab.net/contact/"><p>お問い合わせ</p></a>
            </li>
          </ul>
        </li>
      </ul>
      <div class="footer-a-l-sns">
        <ul class="footer-a-l-s-ul">
          <li>
            <a href="#">
              <div class="sns-icon_common sns-icon_1"></div>
            </a>
          </li>
          <li>
            <a href="#">
              <div class="sns-icon_common sns-icon_2"></div>
            </a>
          </li>
          <li>
            <a href="#">
              <div class="sns-icon_common sns-icon_3"></div>
            </a>
          </li>
        </ul>
      </div>
    </div>
  </div>
  <div class="footer-map">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3071.8291730150654!2d141.1504885157344!3d39.65355890962121!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x5f859cd7258da68d%3A0x5e46b3da84f3b37c!2z44CSMDIwLTA4MzQg5bKp5omL55yM55ub5bKh5biC5rC45LqV77yS77yT5Zyw5Ymy77yR77yY4oiS77yR!5e0!3m2!1sja!2sjp!4v1623390292413!5m2!1sja!2sjp" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
  </div>
  <div class="footer-content">
    <h2>Oikawa Lab</h2>
    <p>〒020-0834 盛岡市永井23地割18番地1オフィスいわて2F<br />TEL 090-9960-2917 <span>E-mail kokokasikosame@gmail.com</span></p>
    <div class="footer-c-border">

    </div>
    <p>及川ラボ｜マーケティングの格安デジタル化支援<br />Copyright Oikawa Lab 2021 All Rights Reserved.</p>
  </div>
</footer>


<?php wp_footer(); ?>

</body>
</html>
