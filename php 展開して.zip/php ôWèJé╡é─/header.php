<!DOCTYPE html><!--htmlで書かれていることを宣言-->
<html lang="ja">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0 ">
  <link rel="shortcut icon" href="<?php echo get_template_directory_uri(); ?>/image/common/fav.png">

  <?php if(is_home() || is_front_page()):?>
    <title><?php bloginfo('name'); ?></title>
  <?php else : ?>
    <title><?php wp_title('及川ラボ｜', true, 'left'); ?></title>
  <?php endif; ?>


  <?php if(is_home() || is_front_page()):?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/home.css" type="text/css" />
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/common.css" type="text/css" />
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/footer.css" type="text/css" />
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/header.css" type="text/css" />
  <?php else : ?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/common.css" type="text/css" />
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/footer.css" type="text/css" />
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/header.css" type="text/css" />
  <?php endif; ?>

  <?php if(is_page('service')):?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/service.css" type="text/css" />
  <?php endif; ?>
  <?php if(is_page('webdesign') ):?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/service_under_webdesign.css" type="text/css" />
  <?php endif; ?>
  <?php if(is_page('webmanagement') ):?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/service_under_webmanagement.css" type="text/css" />
  <?php endif; ?>
  <?php if(is_page('snsmanagement')):?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/service_under_snsmanagement.css" type="text/css" />
  <?php endif; ?>
  <?php if(is_page('videodirection') ):?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/service_under_videodirection.css" type="text/css" />
  <?php endif; ?>

  <?php if(is_page('case')):?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/case.css" type="text/css" />
  <?php endif; ?>
  <?php if(is_page('case-webdesign') ):?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/case_under_common.css" type="text/css" />
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/case_under_webdesign.css" type="text/css" />
  <?php endif; ?>
  <?php if(is_page('case-webmanagement') ):?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/case_under_common.css" type="text/css" />
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/case_under_webmanagement.css" type="text/css" />
  <?php endif; ?>
  <?php if(is_page('case-snsmanagement') ):?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/case_under_common.css" type="text/css" />
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/case_under_snsmanagement.css" type="text/css" />
  <?php endif; ?>
  <?php if(is_page('case-videodirection') ):?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/case_under_common.css" type="text/css" />
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/case_under_videodirection.css" type="text/css" />
  <?php endif; ?>

  <?php if(is_page('company')):?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/company.css" type="text/css" />
  <?php endif; ?>

  <?php if(is_page('philosophy')):?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/philosophy.css" type="text/css" />
  <?php endif; ?>


  <?php if(is_single()):?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/single.css" type="text/css" />
  <?php endif; ?>

  <?php wp_head(); ?>

  <!-- Global site tag (gtag.js) - Google Analytics -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=G-1LH7D8BH2N"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'G-1LH7D8BH2N');
  </script>

</head>
<body <?php body_class(); ?>>

  <header>
    <div class="h-content">
      <ul class="h-c-ul">
        <li class="h-c-u-li_logo">
          <div class="h-c-u-ll-frame">
            <?php
            if(is_home() || is_front_page()) {
              $title_tag_start = '<h1 class="site-title">';
              $title_tag_end = '</h1>';
            } else {
              $title_tag_start = '<p class="site-title">';
              $title_tag_end =  '</p>';
            }
            ?>

            <!--タイトルを画像にする場合-->
            <div class="site-title-wrap">
              <?php echo $title_tag_start; ?>
                <a href="<?php echo home_url(); ?>">
                  <img src="<?php echo get_template_directory_uri() ?>/image/common/common_com_logo3.png">
                </a>
              <?php echo $title_tag_end; ?>
            </div>

          </div>
        </li>
        <li class="h-c-u-li_menu">
          <!--ヘッダーメニュー-->
          <div id="header-nav-wrap" class="header-nav-wrap pc-menu">
          <?php wp_nav_menu( array(
                'theme_location' => 'header-nav',
                'container' => 'nav',
                'container_class' => 'header-nav',
                'container_id' => 'header-nav',
                'fallback_cb' => ''
          ) ); ?>
          </div>
        </li>
      </ul>
      <ul class="h-c-ul_sp">
        <li class="h-c-us-logo">
          <div class="h-c-us-l-frame">
            <?php
            if(is_home() || is_front_page()) {
              $title_tag_start = '<h1 class="site-title">';
              $title_tag_end = '</h1>';
            } else {
              $title_tag_start = '<p class="site-title">';
              $title_tag_end =  '</p>';
            }
            ?>

            <!--タイトルを画像にする場合-->
            <div class="site-title-wrap">
              <?php echo $title_tag_start; ?>
                <a href="<?php echo home_url(); ?>">
                  <img src="<?php echo get_template_directory_uri() ?>/image/common/common_com_logo3.png">
                </a>
              <?php echo $title_tag_end; ?>
            </div>
          </div>
        </li>
        <li class="h-c-us-menu">
          <ul class="h-c-us-m-ul">
            <li class="h-c-us-m-u-contact">
              <div class="h-c-us-m-u-c-frame">
                <a href="#">
                  <p>Contact</p>
                </a>
              </div>
            </li>
            <li class="h-c-us-m-u-menu">
              <div class="h-c-us-m-u-m-frame1 navbutton" id="navbutton">
                <div class="navbutton-under">

                </div>
              </div>
            </li>
          </ul>
        </li>
      </ul>

      <!--ヘッダーメニュー-->
      <div id="header-nav-wrap-sp" class="header-nav-wrap sp-menu">
      <?php wp_nav_menu( array(
            'theme_location' => 'header-nav',
            'container' => 'nav',
            'container_class' => 'header-nav',
            'container_id' => 'header-nav',
            'fallback_cb' => ''
      ) ); ?>
      </div>

    </div>
  </header>
